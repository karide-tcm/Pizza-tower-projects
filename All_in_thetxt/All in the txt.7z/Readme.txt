Am too tired to do a readme just see the gamebanana page and do your thing

#-----Credits

All the members of the Pizza tower discord server 
Specially "complex"

The spanish translation team

